'''
Created on Jan 25, 2017

This is a practice project for those learning Python,
which was exported Eclipse Neon 2 (version 4.6.2). No
updates should be made without the author's consent.
This file is to be copy/pasted into a new project on
a personal computer.

For those using this program, run this program and 
attempt to answer all the questions before reading any
of the written code.

@version: 1.0
@author: Brandon Thompson
@since: 25 January, 2017
'''

totalCorrect = 0
totalQuestions = 0

#Question 1
answerA = input("What data type is \"a = 12\"?\nA: String\nB: Integer\nC: Double\nD: Character\n\n")
if answerA == "B" or answerA == "b" or answerA == "Integer" or answerA == "int":
    print("Correct!")
    totalCorrect += 1
else:
    print("Incorrect! It is an Integer, or int data type.")
print()
input("\nPress enter to continue.")
print()
totalQuestions += 1

#Question 2
answerB = input("What data type is \"b = \"Hello World\"\"?\nA: String\nB: Integer\nC: Double\nD: Character\n\n")
if answerB == "A" or answerB == "a" or answerB == "String" or answerB == "str":
    print("Correct!")
    totalCorrect += 1
else:
    print("Incorrect! It is a String, or str data type.")
print()
input("\nPress enter to continue.")
print()
totalQuestions += 1

#Question 3
answerC = input("What is used for single line comments?\nA: '''\nB: \\\\\nC: #\n\n")
if answerC == "C" or answerC == "c" or answerC == "#":
    print("Correct!")
    totalCorrect += 1
else:
    print("Incorrect! It is \"#\" symbol.")
print()
input("\nPress enter to continue.")
print()
totalQuestions += 1

#Question 4
answerD = input("What method do you use to print out text like this?\nA: print()\nB: printToConsole()\nC: prt()\nD: out()\n\n")
if answerD == "A" or answerD == "a" or answerD == "print()":
    print("Correct!")
    totalCorrect += 1
else:
    print("Incorrect! It is \"print()\".")
print()
input("\nPress enter to continue.")
print()
totalQuestions += 1

#Question 5
answerE = input("We use a dash to inform the compiler we are in a method.\nA: True\nB: False\n\n")
if answerE == "A" or answerE == "a" or answerE == "True" or answerE == "true":
    print("Correct!")
    totalCorrect += 1
else:
    print("Incorrect! We use any amounts of white space to inform the compiler.")
print()
input("\nPress enter to continue.")
print()
totalQuestions += 1

#Question 6
answerF = input("How many different statement names are there for an If case?\nA: 1\nB: 2\nC: 3\n\n")
if answerF == "C" or answerF == "c" or answerF == "3":
    print("Correct!")
    totalCorrect += 1
else:
    print("Incorrect! There are 3; If, Else if, and Else.")
print()
input("\nPress enter to continue.")
print()
totalQuestions += 1

#Question 7
answerG = input("What does \"a\" do in \"for a in range(1, 20)\"?\nA: is a key word in the For loop\nB: is a variable in range()\nC: creates a string of \"1, 20\"\n\n")
if answerG == "B" or answerG == "b" or answerG == "is a variable in range()":
    print("Correct!")
    totalCorrect += 1
else:
    print("Incorrect! The variable \"a\" reads every value from 1 to 20, in the range().")
print()
input("\nPress enter to continue.")
print()
totalQuestions += 1

#Question 8
answerH = input("While loops must have the \"in\" keyword.\nA: True\nB: False\n\n")
if answerH == "B" or answerH == "b" or answerH == "False" or answerH == "false":
    print("Correct!")
    totalCorrect += 1
else:
    print("Incorrect! While loops only need the keys \"while\" and \":\".")
print()
input("\nPress enter to continue.")
print()
totalQuestions += 1

#Final Total
print()
print("Your total correct answers are: " + str(totalCorrect) + " out of " + str(totalQuestions))